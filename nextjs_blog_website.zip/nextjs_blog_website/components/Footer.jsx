import React from 'react'

const Footer = () => {
  return (
    <div className='py-10 text-center'>
        Copyright © 2024 All rights reserved.
        <br />
        This website is made with ♡ by LightCode.
    </div>
  )
}

export default Footer